<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	
	
	

	
	<!-- bootstrap fontawesome -->
	<link rel="stylesheet" href="/book/Public/Admin/css/bootstrap.css"/>
	<link rel="stylesheet" href="/book/Public/Common/css/font-awesome.min.css"/>
	<!--JQuery  -->
	<script src="/book/Public/Common/js/jquery.min.js"></script>
	<!--date picker  -->
	<link rel="stylesheet" href="/book/Public/Common/css/bootstrap-datetimepicker.min.css"/>
	<script src="/book/Public/Common/js/bootstrap-datetimepicker.min.js"></script>
	<script src="/book/Public/Common/js/bootstrap-datetimepicker.zh-CN.js"></script>
	<!--custom css  -->
	<link rel="stylesheet" href="/book/Public/Admin/css/style.css"/>
</head>
<body>
<div class="top">
	<h1 class="left">travel life <span>后台管理系统</span></h1>
	<ul class="right">
		<li>欢迎您：<?php echo ($admin_name); ?></li>
		<li>管理员级别：<?php echo ($admin_priv); ?></li>
		<li><a href="/book/index.php/" target="_blank">前台首页</a></li>
		<li><a href="<?php echo U('Login/logout');?>">退出登录</a></li>
	</ul>
</div>
<div class="main">
	<div class="menu left">
		<div class="box">
			<div class="head"><i></i><div>管理菜单</div></div>
			<ul><li><a href="<?php echo U('Index/index');?>">后台首页</a></li>
				<li><a href="<?php echo U('Product/add');?>" id="Product_add">酒店添加</a></li>
				<li><a href="<?php echo U('Product/index');?>" id="Product_index">酒店列表</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('Category/add');?>" id="Category_add">分类添加</a></li>
					<li><a href="<?php echo U('Category/index');?>" id="Category_index">分类列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Recycle/index');?>" id="Recycle_index">回收站</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('User/index');?>" id="User_index">会员列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Admin/index');?>" id="Admin_index">管理员</a></li>
				
			</ul>
		</div>
	</div>
	<div class="content">
		<div class="item">
 

<div class="title">后台首页</div>
<dl class="bordered">
	<dt>欢迎访问</dt>
	<dd>欢迎进入后台！请从左侧选择一个操作。</dd>
	<dd></dd>
</dl>
 <dl class="bordered">
	<dt>服务器信息</dt>
	<dd>系统环境：<?php echo ($serverInfo['server_version']); ?></dd>
	<dd>服务器时间：<?php echo ($serverInfo['server_time']); ?></dd>
	<dd>MySQL版本：<?php echo ($serverInfo['mysql_version']); ?></dd>
	<dd>文件上传限制：<?php echo ($serverInfo['max_upload']); ?></dd>
	<dd>脚本执行时限：<?php echo ($serverInfo['max_ex_time']); ?></dd>
</dl> </div>
	</div>
</div>
<script>
	$("#<?php echo (CONTROLLER_NAME); ?>_<?php echo (ACTION_NAME); ?>").addClass("curr");
</script>
</body>
</html>