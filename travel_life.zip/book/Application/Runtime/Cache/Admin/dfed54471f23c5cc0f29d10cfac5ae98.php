<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	
	
	

	
	<!-- bootstrap fontawesome -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Admin/css/bootstrap.css"/>
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/font-awesome.min.css"/>
	<!--JQuery  -->
	<script src="/trip/ThinkPHP--master/Public/Common/js/jquery.min.js"></script>
	<!--date picker  -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/bootstrap-datetimepicker.min.css"/>
	<script src="/trip/ThinkPHP--master/Public/Common/js/bootstrap-datetimepicker.min.js"></script>
	<script src="/trip/ThinkPHP--master/Public/Common/js/bootstrap-datetimepicker.zh-CN.js"></script>
	<!--custom css  -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Admin/css/style.css"/>
</head>
<body>
<div class="top">
	<h1 class="left">travel life <span>后台管理系统</span></h1>
	<ul class="right">
		<li>欢迎您：<?php echo ($admin_name); ?></li>
		<li>管理员级别：<?php echo ($admin_priv); ?></li>
		<li><a href="/trip/ThinkPHP--master/index.php/" target="_blank">前台首页</a></li>
		<li><a href="<?php echo U('Login/logout');?>">退出登录</a></li>
	</ul>
</div>
<div class="main">
	<div class="menu left">
		<div class="box">
			<div class="head"><i></i><div>管理菜单</div></div>
			<ul><li><a href="<?php echo U('Index/index');?>">后台首页</a></li>
				<li><a href="<?php echo U('Product/add');?>" id="Product_add">酒店添加</a></li>
				<li><a href="<?php echo U('Product/index');?>" id="Product_index">酒店列表</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('Category/add');?>" id="Category_add">分类添加</a></li>
					<li><a href="<?php echo U('Category/index');?>" id="Category_index">分类列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Recycle/index');?>" id="Recycle_index">回收站</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('User/index');?>" id="User_index">会员列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Admin/index');?>" id="Admin_index">管理员</a></li>
				
			</ul>
		</div>
	</div>
	<div class="content">
		<div class="item"><div class="title">分类修改</div>
<div class="top-button">
	相关操作：<a href="<?php echo U('Category/index');?>" class="light">分类列表</a>
</div>
<div class="list auto">
	<form method="post">
	<input type="hidden" name="id" value="<?php echo ($id); ?>">
	<table class="t2 t3">
		<tr><th>上级分类：</th><td>
			<select name="pid">
				<option value="0">顶级分类</option>
				<?php if(is_array($category)): foreach($category as $key=>$v): ?><option value="<?php echo ($v["id"]); ?>" <?php if(($v["id"]) == $pid): ?>selected<?php endif; ?> ><?php echo str_repeat('— ',$v['level']); echo ($v["name"]); ?></option><?php endforeach; endif; ?>
			</select>
		</td></tr>
		<tr><th>分类名称：</th><td><input type="text" name="name" value="<?php echo ($name); ?>"></td></tr>
	</table>
	<div class="btn1">
		<button type="submit" class="btn btn-primary" ><i class="icon-save"></i> 修改分类</button>
	</div>
	</form>
</div></div>
	</div>
</div>
<script>
	$("#<?php echo (CONTROLLER_NAME); ?>_<?php echo (ACTION_NAME); ?>").addClass("curr");
</script>
</body>
</html>