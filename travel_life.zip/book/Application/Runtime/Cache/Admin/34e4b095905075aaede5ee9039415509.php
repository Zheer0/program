<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	
	
	

	
	<!-- bootstrap fontawesome -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Admin/css/bootstrap.css"/>
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/font-awesome.min.css"/>
	<!--JQuery  -->
	<script src="/trip/ThinkPHP--master/Public/Common/js/jquery.min.js"></script>
	<!--date picker  -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/bootstrap-datetimepicker.min.css"/>
	<script src="/trip/ThinkPHP--master/Public/Common/js/bootstrap-datetimepicker.min.js"></script>
	<script src="/trip/ThinkPHP--master/Public/Common/js/bootstrap-datetimepicker.zh-CN.js"></script>
	<!--custom css  -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Admin/css/style.css"/>
</head>
<body>
<div class="top">
	<h1 class="left">travel life <span>后台管理系统</span></h1>
	<ul class="right">
		<li>欢迎您：<?php echo ($admin_name); ?></li>
		<li>管理员级别：<?php echo ($admin_priv); ?></li>
		<li><a href="/trip/ThinkPHP--master/index.php/" target="_blank">前台首页</a></li>
		<li><a href="<?php echo U('Login/logout');?>">退出登录</a></li>
	</ul>
</div>
<div class="main">
	<div class="menu left">
		<div class="box">
			<div class="head"><i></i><div>管理菜单</div></div>
			<ul><li><a href="<?php echo U('Index/index');?>">后台首页</a></li>
				<li><a href="<?php echo U('Product/add');?>" id="Product_add">酒店添加</a></li>
				<li><a href="<?php echo U('Product/index');?>" id="Product_index">酒店列表</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('Category/add');?>" id="Category_add">分类添加</a></li>
					<li><a href="<?php echo U('Category/index');?>" id="Category_index">分类列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Recycle/index');?>" id="Recycle_index">回收站</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('User/index');?>" id="User_index">会员列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Admin/index');?>" id="Admin_index">管理员</a></li>
				
			</ul>
		</div>
	</div>
	<div class="content">
		<div class="item"><div class="title">产品列表</div>
<div class="top-button">
	选择产品分类：<select id="category">
		<option value="-1" >全部</option>
		<option value="0" <?php if(($cid) == "0"): ?>selected<?php endif; ?>>未分类</option>
		<?php if(is_array($category)): foreach($category as $key=>$v): ?><option value="<?php echo ($v["id"]); ?>" <?php if(($v["id"]) == $cid): ?>selected<?php endif; ?>><?php echo str_repeat('— ',$v['level']); echo ($v["name"]); ?></option><?php endforeach; endif; ?>
	</select>
	<a href="<?php echo U('Product/add',array('cid'=>$cid));?>" class="btn btn-primary"><i class="icon-plus"></i> 添加产品</a>
	<!-- <a href="<?php echo U('Category/add');?>" class="btn btn-primary"><i class="icon-plus"></i> 添加分类</a> -->
</div>

	<table class="ui-table bg-white">
	<thead>
		<tr>
		<th width="10%">产品分类</th>
		<th>产品名称</th>
		<th width="10%">库存</th>
		<th width="10%">上架</th>
		<th width="10%">推荐</th>
		<th width="20%">操作</th>
		</tr>
	</thead>
	<tbody>
		<?php if(is_array($product["data"])): foreach($product["data"] as $key=>$v): ?><tr>
			<td>
				<?php if(empty($v["category_id"])): ?><a href="<?php echo U('Product/index','cid=0');?>">未分类</a>
				<?php else: ?>
					<a href="<?php echo U('Product/index',array('cid'=>$v['category_id']));?>"><?php echo ($v["category_name"]); ?></a><?php endif; ?>
			</td>
			<td><?php echo ($v["name"]); ?></td><td><?php echo ($v["stock"]); ?></td>
			<td><a href="#" class="act-onsale" data-id="<?php echo ($v["id"]); ?>" data-status="<?php echo ($v["on_sale"]); ?>"><?php if(($v["on_sale"]) == "yes"): ?>是<?php else: ?>否<?php endif; ?></a></td>
			<td><a href="#" class="act-recommend" data-id="<?php echo ($v["id"]); ?>" data-status="<?php echo ($v["recommend"]); ?>"><?php if(($v["recommend"]) == "yes"): ?>是<?php else: ?>否<?php endif; ?></a></td><td>
			<a href="<?php echo U('Product/edit',array('id'=>$v['id'],'cid'=>$v['category_id'],'p'=>$p));?>" class="btn btn-primary"><i class="icon-edit"></i> 修改</a>　<a href="#" class="btn btn-danger act-del" data-id="<?php echo ($v["id"]); ?>"><i class="icon-trash"></i> 删除</a></td>
			</tr><?php endforeach; endif; ?>
	</tbody>
	</table>

<div class="pagelist"><?php echo ($product["pagelist"]); ?></div>
<form method="post" id="form">
	<input type="hidden" name="id" id="target_id">
	<input type="hidden" name="field" id="target_field">
	<input type="hidden" name="status" id="target_status">
</form>
<script>
	//下拉菜单跳转
	$("#category").change(function(){
		var url = "<?php echo U('Product/index',array('cid'=>'_ID_'));?>";
		location.href = url.replace("_ID_",$(this).val());
	});
	<?php if(($priv) == "0"): ?>//快捷操作-推荐 推荐只有管理员能执行
		$(".act-recommend").click(function(){
			change_status($(this),'recommend');
		});<?php endif; ?>
	//快捷操作
	function change_status(obj,field){
		$("#target_id").val(obj.attr("data-id"));
		$("#target_field").attr("value",field)
		$("#target_status").attr("value",(obj.attr("data-status")=="yes") ? "no" : "yes");
		$("#form").attr("action","<?php echo U('Product/change',array('p'=>$p,'cid'=>$cid));?>").submit();
	}
	//快捷操作-上架
	$(".act-onsale").click(function(){
		change_status($(this),'on_sale');
	});
	
	//快捷操作-删除
	$(".act-del").click(function(){
		if(confirm('确定要删除吗？')){
			$("#target_id").val($(this).attr("data-id"));
			$("#form").attr("action","<?php echo U('Product/del',array('p'=>$p,'cid'=>$cid));?>").submit();
		}
	});
	
</script></div>
	</div>
</div>
<script>
	$("#<?php echo (CONTROLLER_NAME); ?>_<?php echo (ACTION_NAME); ?>").addClass("curr");
</script>
</body>
</html>