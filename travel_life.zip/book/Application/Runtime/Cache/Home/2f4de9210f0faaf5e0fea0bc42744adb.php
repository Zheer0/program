<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
<title>旅游人生</title>

<!--默认使用chrome内核进行渲染  -->
<meta name="renderer" content="webkit|ie-comp|ie-stand">

<!--安装了GCF后，可以让ie调用chrome内核进行渲染  -->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="http://apps.bdimg.com/libs/html5shiv/3.7/html5shiv.min.js"></script>
  <script src="http://apps.bdimg.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- jQuery (necessary for Bootstrap's JavaScript ) -->
<script src="/book/Public/Home/js/jquery-1.11.0.min.js"></script>
<!--  Bootstrap -->
<script src="/book/Public/Home/js/bootstrap.min.js"></script>
<link href="/book/Public/Home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">



<!-- Custom Theme files -->
<!--  <link href="/book/Public/Home/css/style.css" rel="stylesheet" type="text/css" media="all"/>-->
<link href="/book/Public/Home/css/main.css" rel="stylesheet" type="text/css" media="all"/>

<!-- buttons.css -->	
<link href="/book/Public/Home/css/buttons.css" rel="stylesheet" type="text/css" media="all"/>

<!--  fontawesome -->
<link rel="stylesheet" href="/book/Public/Common/css/font-awesome.min.css"/>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!--favicon.ico  -->
<link rel="icon" href="/book/Public/Home/img/favicon.ico" mce_href="/book/Public/Home/img/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/book/Public/Home/img/favicon.ico">
<!--百度统计  -->

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?d57f9e6d0ea1527c4470d760bd71f2b9";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>



</head>
<body>
<div class="wrap">
<!--banner start here-->

  <div class="header">
	
		<!--navbar start here-->
            <div class="navbar-warp">
            <nav class="navbar navbar-default " role="navigation">
              
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand">
                  <img src="/book/Public/Home/img/logo_small.png" alt="Brand">
                  </a>
                </div>
            
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav">
                  	<li role="presentation"  id="0";><a href="<?php echo U('Index/index');?>">首页</a></li>

                  </ul>
					<ul class="nav navbar-nav">
						<li role="presentation"><a href="http://localhost/tp5/public/index.php/">Blog</a></li>
					</ul>
                  <form method="get" class="navbar-form navbar-right" role="search">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Search" name="keyword" id="search">
                    </div>
                    <button type="button" class="btn btn-default" onclick="searchproduct()">搜索</button>
                  </form>
                  <ul class="nav navbar-nav navbar-right">
                    <?php if(isset($userinfo["id"])): ?><li><a href="<?php echo U('Order/index');?>">欢迎您&nbsp;<?php echo ($userinfo["name"]); ?></a></li>
                    <li><a href="<?php echo U('User/logout');?>">退出</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo U('User/login');?>">登录</a></li><li><a href="<?php echo U('User/register');?>">注册</a></li><?php endif; ?>                    
                  </ul>
                </div><!-- /.navbar-collapse -->
             
            </nav>
            </div>
            <!--navbar end-->
<script type="text/javascript" src="/book/Public/Home/js/myfocus-2.0.1.min.js"></script><!--引入myFocus库-->
<script type="text/javascript">
myFocus.set({
    id:'boxID',//焦点图盒子ID
    pattern:'mF_games_tb',//风格应用的名称
    time:10,//切换时间间隔(秒)
    trigger:'click',//触发切换模式:'click'(点击)/'mouseover'(悬停)
    width:690,//设置图片区域宽度(像素)
    height:400,//设置图片区域高度(像素)
    txtHeight:0//文字层高度设置(像素),'default'为默认高度，0为隐藏
});
</script>

<!--detail start here-->
	<div class="top">
		<div class="position">
			<a href="<?php echo U('Index/index');?>">首页</a> > 
			<?php if(is_array($path)): foreach($path as $key=>$v): ?>&nbsp;<a href="<?php echo U('Index/find',array('cid'=>$v['id']));?>"><?php echo ($v["name"]); ?></a>&nbsp;&gt;<?php endforeach; endif; ?>&nbsp;<?php echo ($product["name"]); ?>
		</div>
		<div class="tour-show">
			<div class="tour-show-left">
			<div id="boxID"><!--焦点图盒子-->
			<div class="loading"><img src="/book/Public/Home/img/loading.gif" alt="请稍候..." /></div><!--载入画面(可删除)-->
  			<div class="pic"><!--内容列表(li数目可随意增减)-->
  			<ul>
  				<li><img src="/book/Public/Uploads/<?php echo ($product["pic1"]); ?>" thumb="" alt="" text="" /></li>
  				<li><img src="/book/Public/Uploads/<?php echo ($product["pic2"]); ?>" thumb="" alt="" text="" /></li>
  				<li><img src="/book/Public/Uploads/<?php echo ($product["pic3"]); ?>" thumb="" alt="" text="" /></li>
  				<li><img src="/book/Public/Uploads/<?php echo ($product["pic4"]); ?>" thumb="" alt="" text="" /></li>
  				<li><img src="/book/Public/Uploads/<?php echo ($product["pic5"]); ?>" thumb="" alt="" text="" /></li>
  			</ul>
  			</div>
		</div>	
			</div>
			<div class="tour-show-right">
				<h3><?php echo ($product["name"]); ?></h3>
				<div class="confirm">
					<?php if(!empty($product["sn"])): ?><span class="price_small_blue">【产品编码】<?php echo ($product["sn"]); ?></span><br/><?php endif; ?>
					<?php if(($product["confirm"]) == "yes"): ?><span class="price_small_blue">二次确认（本产品下单后，我们会与您联系核实出游信息）</span><?php endif; ?>
					
				</div>
				
				<div class="price-wrap">
					<?php if(($product["price"]) == "0"): ?>￥实时计价
					<?php else: ?>
						￥<?php echo ($product["price"]); ?><span class="price_small_red">人起</span><?php endif; ?>
					<?php if(!empty($product["market_price"])): ?><span class="price_small"> 门市价 </span><span class="del">￥<?php echo ($product["market_price"]); ?></span><?php endif; ?>
					<?php if(!empty($product["child_price"])): ?><span class="price_small_red">儿童价￥<?php echo ($product["child_price"]); ?></span><?php endif; ?>
				</div>
				
				<div class="buy_num">
				<div class="buy_num_left">
					<?php if(!empty($product["plan1_name"])): echo ($product["plan1_name"]); ?>:<span class="price_small_red">  <?php echo ($product["plan1_price"]); ?> 元</span><br><?php endif; ?>	
					<?php if(!empty($product["plan2_name"])): echo ($product["plan2_name"]); ?>:<span class="price_small_red">  <?php echo ($product["plan2_price"]); ?> 元</span><br><?php endif; ?>		
					<?php if(!empty($product["plan3_name"])): echo ($product["plan3_name"]); ?>:<span class="price_small_red">  <?php echo ($product["plan3_price"]); ?> 元</span><br><?php endif; ?>
				</div>	
				<div class="buy_num_right">
					<?php if(!empty($product["plan4_name"])): echo ($product["plan4_name"]); ?>:<span class="price_small_red">  <?php echo ($product["plan4_price"]); ?> 元</span><br><?php endif; ?>	
					<?php if(!empty($product["plan5_name"])): echo ($product["plan5_name"]); ?>:<span class="price_small_red">  <?php echo ($product["plan5_price"]); ?> 元</span><br><?php endif; ?>		
					<?php if(!empty($product["plan6_name"])): echo ($product["plan6_name"]); ?>:<span class="price_small_red">  <?php echo ($product["plan6_price"]); ?> 元</span><br><?php endif; ?>
				</div>	
				<div class="buy_num_bottom">		
					购买数量：
						<input type="button" value="-" class="cnt-btn" />
						<input type="text" value="1" id="num" class="num-btn" />
						<input type="button" value="+" class="cnt-btn" />&nbsp;
						库存：<span class="price_small_red"><?php echo ($product["stock"]); ?></span>
				</div>
				</div>
				<div class="TagList">
                    	<span title="" class="Tag"><?php echo ($product["highlight1"]); ?></span>
                    <?php if(!empty($product["highlight2"])): ?><span title="" class="Tag"><?php echo ($product["highlight2"]); ?></span><?php endif; ?>
                    <?php if(!empty($product["highlight3"])): ?><span title="" class="Tag"><?php echo ($product["highlight3"]); ?></span><?php endif; ?>	
 				</div>
 				<div class="btn">
 					<span id="submbuy">立即预定</span>
 				</div>
 				<div>
 					<p>若该产品不匹配您的预算计划或不满足您的需求，请在首页点击“个人定制”，我们将根据您的要求微调出行方案或为您定制个性化方案。</p>
 				</div>
 				<form method="post" action="<?php echo U('Order/buy');?>" id="form_buy">
				<input type="hidden" name="buy[0][id]" value="<?php echo ($product["id"]); ?>">
				<input type="hidden" name="buy[0][num]" value="" id="form_num">
				</form>
			</div> <!--tour-show-right end-->
		</div> <!--tour-show end-->	
   </div>
	<!--container end--> 
	<!--detail navi bar start-->
	<div class="detail_navbar">
	<ul class="nav nav-tabs">
			<li><a href="#product-detail" class="active">产品详情</a></li>
 			<li><a href="#cost-description">费用说明</a></li>
			<li><a href="#reserve-notice">预定须知</a></li>
			<li><a href="#return-restriction">退改规定</a></li>
	</ul>
	</div>
	<!--detail navi bar end-->
	<!--detail wrap start-->
	<div class="detail-wrap">
		<div class="detail">
			<div class="detail-left">
			<!-- start of 产品详情 -->
			<div class="ProInfoBox" id="product-detail">
				<p class="TourInfoHeadBig">产品详情</p><br>

				<?php if(!empty($product["continent"])): ?><strong>【所属大洲】</strong> <?php echo ($product["continent"]); ?><br><?php endif; ?>
				<?php if(!empty($product["country"])): ?><strong>【所属国家】</strong> <?php echo ($product["country"]); ?><br><?php endif; ?>
				<?php if(!empty($product["days"])): ?><strong>【行程天数】</strong> <?php echo ($product["days"]); ?><br><?php endif; ?>
				<!-- 签证属性 -->
				<?php if(!empty($product["place_of_issue"])): ?><strong>【护照签发地】</strong> <?php echo ($product["place_of_issue"]); ?><br><?php endif; ?>
				<?php if(!empty($product["visa_type"])): ?><strong>【签证代办类型】</strong> <?php echo ($product["visa_type"]); ?><br><?php endif; ?>
				<?php if(!empty($product["sent_visa_place"])): ?><strong>【送签地】</strong> <?php echo ($product["sent_visa_place"]); ?><br><?php endif; ?>
				
				<!--线路属性 -->
				<?php if(!empty($product["city"])): ?><strong>【所在城市】</strong> <?php echo ($product["city"]); ?><br><?php endif; ?>
				<?php if(!empty($product["detail_property"])): ?><strong>【产品主题】</strong> <?php echo ($product["detail_property"]); ?><br><?php endif; ?>
				<!--邮轮属性 -->
				<?php if(!empty($product["ship_depart_city"])): ?><strong>【出发城市】</strong> <?php echo ($product["ship_depart_city"]); ?><br><?php endif; ?>
				<?php if(!empty($product["ship_route"])): ?><strong>【邮轮航线】</strong> <?php echo ($product["ship_route"]); ?><br><?php endif; ?>
				<?php if(!empty($product["ship_company"])): ?><strong>【邮轮公司】</strong> <?php echo ($product["ship_company"]); ?><br><?php endif; ?>
				<?php if(!empty($product["ship_name"])): ?><strong>【船名】</strong> <?php echo ($product["ship_name"]); ?><br><?php endif; ?>
				<?php if(!empty($product["ship_depart_time"])): ?><strong>【出游日期】</strong> <?php echo ($product["ship_depart_time"]); ?><br><?php endif; ?>
				
				
				<?php if(!empty($product["sn"])): ?><strong>【产品编码】</strong> <?php echo ($product["sn"]); ?><br><?php endif; ?>
				<?php if(!empty($product["people"])): ?><strong>【出游人群】</strong> <?php echo ($product["people"]); ?><br><?php endif; ?>
				<?php if(!empty($product["start_time"])): ?><strong>【出游日期】</strong> <?php echo ($product["start_time"]); ?><br><?php endif; ?>
				
				
				<?php if(!empty($product["start"])): ?><strong>【出发地】</strong>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($product["start"]); ?><br><?php endif; ?>
				<?php if(!empty($product["path"])): ?><strong>【途径】</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($product["path"]); ?><br><?php endif; ?>
				<?php if(!empty($product["end"])): ?><strong>【目的地】</strong> &nbsp;&nbsp;&nbsp;<?php echo ($product["end"]); ?><br><?php endif; ?>
				<?php if(!empty($product["deposit"])): ?><strong>【定金】</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($product["deposit"]); ?><br><?php endif; ?>
				<?php if(!empty($product["language"])): ?><strong>【服务语言】</strong> <?php echo ($product["language"]); ?><br><?php endif; ?>
				<br>
				<?php echo ($product["desc"]); ?>
			</div>
			<!-- 	start of 行程参考 -->
			<div class="tour-info" id="journey-ref">
				<div class="ProInfoBox">
				<p class="TourInfoHeadBig">行程参考</p><br>
				<?php echo ($product["travel_ref"]); ?>
				</div>
			</div>
			<!-- start of tour-info1费用说明 -->
			<div class="tour-info" id="cost-description">
			<p class="TourInfoHeadBig">费用说明:</p>
				<div class="ProInfoBox">
				<?php echo ($product["cost_desc"]); ?>
				</div>
			</div><!-- end of tour-info1 -->						
			
			<!-- start of 预定须知 -->
			<div class="tour-info" id="reserve-notice">
				<div class="ProInfoBox">
					<p class="TourInfoHeadBig">预定须知</p><br>
					<?php echo ($product["reserve_notice"]); ?>			
				</div>
			</div>
			
			<!-- start of 退改规定 -->
			<div class="tour-info" id="return-restriction">	
				<div class="ProInfoBox">
					<p class="TourInfoHeadBig">退改规定</p><br>
					<?php echo ($product["restrict"]); ?>
				</div>
			</div>
			<!-- start of 问题咨询 -->
			<div class="tour-info" id="question-info">	
				<div class="ProInfoBox">
					<p class="TourInfoHeadBig">问题咨询</p><br>
					<?php echo ($product["info"]); ?>
				</div>
			</div>
			</div><!--  end of detail-left -->
			
			
			<div class="detail-right">
				<p>相关产品推荐</p>
				<?php if(is_array($recommend)): foreach($recommend as $key=>$v): ?><a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank" class="Product">
	                <i class="LazyImgBox"><?php if(empty($v["thumb"])): ?><img src="/book/Public/Common/img/preview.jpg"><?php else: ?><img src="/book/Public/Uploads/small/<?php echo ($v["thumb"]); ?>"><?php endif; ?></i>
	                <span><?php echo ($v["name"]); ?></span>
	                <font>￥<?php echo ($v["price"]); ?></font>
					</a><?php endforeach; endif; ?>
			</div><!--  end of detail-right -->
		</div><!--detail  end-->	
		<!--返回顶部  -->
		<div class="Backbox">
	    	<div class="plane plane_1"><a href="#"><i class="icon-angle-up icon-3x"></i></a></div>
		</div>
	</div>		
	<!--detail wrap end-->	
<script>

//购买数量加减
$(".cnt-btn").click(function(){
	var num = parseInt($("#num").val());
	if ($(this).val() === '-') {
		if ( num=== 1) return;
		$("#num").val(num-1);
	}else if ($(this).val() === '+') {
		if (num === <?php echo ($product["stock"]); ?>) return;
		$("#num").val(num+1);
	}
});
//自动纠正购买数量
$("#num").keyup(function(){
	var num = parseInt($(this).val());
	if(num<1){ 
		$(this).val(1);
	}else if(num > <?php echo ($product["stock"]); ?>){
		$(this).val(<?php echo ($product["stock"]); ?>);
	}
});

$("#submbuy").click(function(){
	$("#form_num").val($("#num").val());
	$("#form_buy").submit();
});

$("#submbuy").click(function(){
	var sn = "<?php echo ($product["sn"]); ?>";
	//alert(sn);
	self.location = "<?php echo U('Index/customize');?>?sn=" + sn;
}); 







</script>	     
<!--copyright start-->
<div class="copyright">
		<div class="copyright_content">
			<ul>
				<li><a href="#">关于</a>
					<ul>
       				<li><a href="#">关于我们</a></li>
       				<li><a href="#">联系我们</a></li>
       				<li><a href="#">加入我们</a></li>
        			<li><a href="#">版权声明</a></li>
       				</ul>
				</li>
				<li><a href="#">网站条款</a>
					<ul>
         			<li><a href="#">法律声明</a></li>
        			<li><a href="#">隐私政策</a></li>
       				<li><a href="#">服务条款</a></li>
        			<li><a href="#">用户须知</a></li>
      				</ul>
				</li>
				<li><a href="#">留言</a>
					<ul>
         			<li><a href="#">意见反馈</a></li>
        			<li><a href="#">问题流言</a></li>
       				<li><a href="#">媒体联络</a></li>
        			<li><a href="#">在线客服</a></li>
      				</ul>
				</li>
				<li><a href="#">友情链接</a>
					<ul>
         			<li><a href="#">台湾旅游局</a></li>
        			<li><a href="#">澳大利亚旅游局</a></li>
       				<li><a href="#">日本旅游局</a></li>
        			<li><a href="#">韩国旅游局</a></li>
      				</ul>
				</li>
			</ul>
		</div> <!--endof copyright_content-->
		<div class="copyright_end">
			<!--<div class="copyright_content copyright_small">
                <ul>
                    <li><a href="<?php echo U('Index/introduce/tid/1');?>">关于我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/2');?>">联系我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/3');?>">合作伙伴</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/4');?>">服务条款</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/5');?>">加入我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/6');?>">法律声明</a></li>
                </ul>
      </div>-->

</div> <!--endof copyright-->
<!--footer end here-->
</div>
<!--wrap end here-->


<script>
	//控制顶部导航栏被选中的效果
	<?php if(isset($temp_cid)): ?>$("#<?php echo ($temp_cid); ?>").addClass("active");
	<?php else: ?>
		$("#0").addClass("active");<?php endif; ?>
	
	//搜索功能
	function searchproduct(){
		var keyword = $("#search").val();
		//alert(keyword);
		self.location = "<?php echo U('Index/find');?>?keyword=" + keyword;
	}
</script>
</body>
</html>