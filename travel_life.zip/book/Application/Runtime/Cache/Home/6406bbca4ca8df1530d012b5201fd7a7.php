<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
<title>旅游人生</title>

<!--默认使用chrome内核进行渲染  -->
<meta name="renderer" content="webkit|ie-comp|ie-stand">

<!--安装了GCF后，可以让ie调用chrome内核进行渲染  -->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="http://apps.bdimg.com/libs/html5shiv/3.7/html5shiv.min.js"></script>
  <script src="http://apps.bdimg.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- jQuery (necessary for Bootstrap's JavaScript ) -->
<script src="/trip/ThinkPHP--master/Public/Home/js/jquery-1.11.0.min.js"></script>
<!--  Bootstrap -->
<script src="/trip/ThinkPHP--master/Public/Home/js/bootstrap.min.js"></script>
<link href="/trip/ThinkPHP--master/Public/Home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">



<!-- Custom Theme files -->
<!--  <link href="/trip/ThinkPHP--master/Public/Home/css/style.css" rel="stylesheet" type="text/css" media="all"/>-->
<link href="/trip/ThinkPHP--master/Public/Home/css/main.css" rel="stylesheet" type="text/css" media="all"/>

<!-- buttons.css -->	
<link href="/trip/ThinkPHP--master/Public/Home/css/buttons.css" rel="stylesheet" type="text/css" media="all"/>

<!--  fontawesome -->
<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/font-awesome.min.css"/>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!--favicon.ico  -->
<link rel="icon" href="/trip/ThinkPHP--master/Public/Home/img/favicon.ico" mce_href="/trip/ThinkPHP--master/Public/Home/img/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/trip/ThinkPHP--master/Public/Home/img/favicon.ico">
<!--百度统计  -->

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?d57f9e6d0ea1527c4470d760bd71f2b9";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>



</head>
<body>
<div class="wrap">
<!--banner start here-->

  <div class="header">
	
		<!--navbar start here-->
            <div class="navbar-warp">
            <nav class="navbar navbar-default " role="navigation">
              
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand">
                  <img src="/trip/ThinkPHP--master/Public/Home/img/logo_small.png" alt="Brand">
                  </a>
                </div>
            
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav">
                  	<li role="presentation"  id="0";><a href="<?php echo U('Index/index');?>">首页</a></li>

                  </ul>
                  <form method="get" class="navbar-form navbar-right" role="search">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Search" name="keyword" id="search">
                    </div>
                    <button type="button" class="btn btn-default" onclick="searchproduct()">搜索</button>
                  </form>
                  <ul class="nav navbar-nav navbar-right">
                    <?php if(isset($userinfo["id"])): ?><li><a href="<?php echo U('Order/index');?>">欢迎您&nbsp;<?php echo ($userinfo["name"]); ?></a></li>
                    <li><a href="<?php echo U('User/logout');?>">退出</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo U('User/login');?>">登录</a></li><li><a href="<?php echo U('User/register');?>">注册</a></li><?php endif; ?>                    
                  </ul>
                </div><!-- /.navbar-collapse -->
             
            </nav>
            </div>
            <!--navbar end-->
<div class="find">
<div class="find-left left"><div class="title">相关产品推荐</div>
		<?php if(is_array($product["recommend"])): foreach($product["recommend"] as $key=>$v): ?><ul class="item left">
		<li><a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank"><?php if(empty($v["thumb"])): ?><img src="/trip/ThinkPHP--master/Public/Common/img/preview.jpg"><?php else: ?><img src="/trip/ThinkPHP--master/Public/Uploads/small/<?php echo ($v["thumb"]); ?>"><?php endif; ?></a></li>
		<li class="product"><a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank"><?php echo ($v["name"]); ?></a></li>
		<li class="price">￥<?php echo ($v["price"]); ?></li>
	</ul><?php endforeach; endif; ?>
</div>
<div class="find-right left">
	<ul class="filter">
		<!-- <li class="filter-title">产品列表</li> -->
		<!-- 循环输出分类 -->
		<!-- <?php if(!empty($category["parent"])): if(is_array($category["parent"])): $i = 0; $__LIST__ = $category["parent"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
				<p id="p<?php echo ($i); ?>">
					<?php if($i == 1 ): ?>产品类型：
					<?php else: ?>目的地：<?php endif; ?>
				</p>
				<?php if($i == 1 ): ?><a href="<?php echo mkFilterURL('cid');?>" class="cid-0">全部</a><?php endif; ?>
				<?php if(is_array($v)): foreach($v as $key=>$vv): ?><a href="<?php echo mkFilterURL('cid',$vv['id']);?>" class="cid-<?php echo ($vv["id"]); ?>" id="cid-<?php echo ($vv["id"]); ?>"><?php echo ($vv["name"]); ?></a><?php endforeach; endif; ?></li><?php endforeach; endif; else: echo "" ;endif; endif; ?> -->
		
		<!-- 签证筛选菜单 -->
		<?php if($temp_cid == 1 ): ?><li id="continent"><p>前往大洲：</p>
				<a href="<?php echo mkFilterURL('continent');?>" class="continent-0">不限</a>
				<?php if(is_array($visa_dest)): foreach($visa_dest as $k=>$v): ?><a href="<?php echo mkFilterURL('continent',$k);?>" class="continent-<?php echo ($k); ?>"><?php echo ($k); ?></a><?php endforeach; endif; ?>
			</li>
			<li id="country"><p>国家或地区：</p>
				<a href="<?php echo mkFilterURL('country');?>" class="country-0">不限</a>
			</li>
			<li id="visa_type"><p>签证类型：</p>
				<a href="<?php echo mkFilterURL('visa_type');?>" class="visa_type-0">不限</a>
			</li>
			<li><p>护照签发地：</p>
				<a href="<?php echo mkFilterURL('place_of_issue');?>" class="place_of_issue-0">不限</a>
				<?php if(is_array($place_of_issue)): foreach($place_of_issue as $k=>$v): ?><a href="<?php echo mkFilterURL('place_of_issue',$v);?>" class="place_of_issue-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
			<li><p>送签地：</p>
				<a href="<?php echo mkFilterURL('sent_visa_place');?>" class="sent_visa_place-0">不限</a>
				<?php if(is_array($sent_visa_place)): foreach($sent_visa_place as $k=>$v): ?><a href="<?php echo mkFilterURL('sent_visa_place',$v);?>" class="sent_visa_place-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
		<!--线路筛选菜单  -->
		<?php elseif($temp_cid == 2): ?>
			<li><p>前往大洲：</p>
				<a href="<?php echo mkFilterURL('continent');?>" class="continent-0">不限</a>
				<?php if(is_array($route_dest)): foreach($route_dest as $k=>$v): ?><a href="<?php echo mkFilterURL('continent',$k);?>" class="continent-<?php echo ($k); ?>"><?php echo ($k); ?></a><?php endforeach; endif; ?>
			</li>
			<li id="country"><p>国家：</p>
				<a href="<?php echo mkFilterURL('country');?>" class="country-0">不限</a>
				
			</li>
			<li id="city"><p>城市：</p>
				<a href="<?php echo mkFilterURL('city');?>" class="city-0">不限</a>
			</li>
			<li><p>天数：</p>
				<a href="<?php echo mkFilterURL('days');?>" class="days-0">不限</a>
				<?php if(is_array($days)): foreach($days as $k=>$v): ?><a href="<?php echo mkFilterURL('days',$v);?>" class="days-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
				
			</li>
			<li><p>主题：</p>
				<a href="<?php echo mkFilterURL('detail_property');?>" class="detail_property-0">不限</a>
				<?php if(is_array($detail_property)): foreach($detail_property as $k=>$v): ?><a href="<?php echo mkFilterURL('detail_property',$v);?>" class="detail_property-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
		<!-- 邮轮筛选菜单 -->	
		<?php elseif($temp_cid == 3): ?>	
			<li><p>邮轮航线：</p>
				<a href="<?php echo mkFilterURL('ship_route');?>" class="ship_route-0">不限</a>
				<?php if(is_array($ship_route)): foreach($ship_route as $k=>$v): ?><a href="<?php echo mkFilterURL('ship_route',$v);?>" class="ship_route-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
			<li><p>邮轮公司：</p>
				<a href="<?php echo mkFilterURL('ship_company');?>" class="ship_company-0">不限</a>
				<?php if(is_array($ship_company)): foreach($ship_company as $k=>$v): ?><a href="<?php echo mkFilterURL('ship_company',$v);?>" class="ship_company-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
			<li><p>船名：</p>
				<a href="<?php echo mkFilterURL('ship_name');?>" class="ship_name-0">不限</a>
				<?php if(is_array($ship_name)): foreach($ship_name as $k=>$v): ?><a href="<?php echo mkFilterURL('ship_name',$v);?>" class="ship_name-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
			<li><p>出发地：</p>
				<a href="<?php echo mkFilterURL('ship_depart_city');?>" class="ship_depart_city-0">不限</a>
				<?php if(is_array($ship_depart_city)): foreach($ship_depart_city as $k=>$v): ?><a href="<?php echo mkFilterURL('ship_depart_city',$v);?>" class="ship_depart_city-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li>
			<li><p>出发日期：</p>
				<a href="<?php echo mkFilterURL('ship_depart_time');?>" class="ship_depart_time-0">不限</a>
				<?php if(is_array($ship_depart_time)): foreach($ship_depart_time as $k=>$v): ?><a href="<?php echo mkFilterURL('ship_depart_time',$v);?>" class="ship_depart_time-<?php echo ($v); ?>"><?php echo ($v); ?></a><?php endforeach; endif; ?>
			</li><?php endif; ?>
		<!-- <li><p>价格：</p>
			<a href="<?php echo mkFilterURL('price');?>" class="price-0">全部</a>
			<a href="<?php echo mkFilterURL('price','0-500');?>" class="price-0-500">500元以下</a>
			<a href="<?php echo mkFilterURL('price','500-1000');?>" class="price-500-1000">500-1000元</a>
			<a href="<?php echo mkFilterURL('price','1000-5000');?>" class="price-1000-5000">1000-5000元</a>
			<a href="<?php echo mkFilterURL('price','5000-100000');?>" class="price-5000-100000">5000元以上</a>
		</li>  -->
		<li><p>排序：</p>
		<a href="<?php echo mkFilterURL('order');?>" class="order-0">最新上架</a>
		<a href="<?php echo mkFilterURL('order','price-asc');?>" class="order-price-asc">价格升序</a>
		<a href="<?php echo mkFilterURL('order','price-desc');?>" class="order-price-desc">价格降序</a>
		</li>
	</ul>
	<div class="find-item">
		<?php if(empty($product["data"])): ?><div class="empty-tip">没有找到您需要的产品。</div>
		<?php else: ?>
		<?php if(is_array($product["data"])): foreach($product["data"] as $key=>$v): ?><ul class="item left">
			<li><a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank"><?php if(empty($v["thumb"])): ?><img src="/trip/ThinkPHP--master/Public/Common/img/preview.jpg"><?php else: ?><img src="/trip/ThinkPHP--master/Public/Uploads/small/<?php echo ($v["thumb"]); ?>"><?php endif; ?></a></li>
			<li class="product"><a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank"><?php echo ($v["name"]); ?></a></li>
			<li class="price">￥<?php echo ($v["price"]); ?></li>
		</ul><?php endforeach; endif; ?>
		<div class="clear"></div>
		<div class="pagelist"><?php echo ($product["pagelist"]); ?></div><?php endif; ?>
	</div>
</div>
</div>
<script>

//Think.get.continent：从地址栏取值
//筛选签证目的地,点击洲显示国家
<?php if($temp_cid == 1 ): if(is_array($visa_dest)): foreach($visa_dest as $k=>$v): if($_GET['continent']== $k ): ?>//alert("con");
			$("#country").empty();
			$("#country").append('<p>国家或地区：</p><a href="<?php echo mkFilterURL('country');?>" class="country-0">不限</a>');
			<?php if(is_array($v)): foreach($v as $kk=>$vv): ?>$("#country").append('<a href="<?php echo mkFilterURL('country',$kk);?>" class="country-<?php echo ($kk); ?>"><?php echo ($kk); ?></a>');<?php endforeach; endif; endif; endforeach; endif; ?> 	

<?php elseif($temp_cid == 2 ): ?>
//alert("123");
	<?php if(is_array($route_dest)): foreach($route_dest as $k=>$v): if($_GET['continent']== $k ): ?>//alert("con");
			$("#country").empty();
			$("#country").append('<p>国家或地区：</p><a href="<?php echo mkFilterURL('country');?>" class="country-0">不限</a>');
			<?php if(is_array($v)): foreach($v as $kk=>$vv): ?>$("#country").append('<a href="<?php echo mkFilterURL('country',$kk);?>" class="country-<?php echo ($kk); ?>"><?php echo ($kk); ?></a>');<?php endforeach; endif; endif; endforeach; endif; endif; ?>

//点击国家筛选签证类型,签证
<?php if($temp_cid == 1 ): if(is_array($visa_dest)): foreach($visa_dest as $key=>$zhou): if(is_array($zhou)): foreach($zhou as $k=>$v): if($_GET['country']== $k ): ?>//alert("con");
			$("#visa_type").empty();
			$("#visa_type").append('<p>签证类型：</p><a href="<?php echo mkFilterURL('visa_type');?>" class="visa_type-0">不限</a>');
			<?php if(is_array($v)): foreach($v as $kk=>$vv): ?>$("#visa_type").append('<a href="<?php echo mkFilterURL('visa_type',$vv);?>" class="visa_type-<?php echo ($vv); ?>"><?php echo ($vv); ?></a>');<?php endforeach; endif; endif; endforeach; endif; endforeach; endif; endif; ?> 


//点击国家筛选城市,线路
<?php if($temp_cid == 2 ): if(is_array($route_dest)): foreach($route_dest as $key=>$zhou): if(is_array($zhou)): foreach($zhou as $k=>$v): if($_GET['country']== $k ): ?>//alert("con");
			$("#city").empty();
			$("#city").append('<p>城市：</p><a href="<?php echo mkFilterURL('city');?>" class="city-0">不限</a>');
			<?php if(is_array($v)): foreach($v as $kk=>$vv): ?>$("#city").append('<a href="<?php echo mkFilterURL('city',$vv);?>" class="city-<?php echo ($vv); ?>"><?php echo ($vv); ?></a>');<?php endforeach; endif; endif; endforeach; endif; endforeach; endif; endif; ?> 



//产品排序的选中效果
<?php if(isset($_GET['order'])): ?>$(".order-<?php echo ($_GET['order']); ?>").addClass("curr");
<?php else: ?>
	$(".order-0").addClass("curr");<?php endif; ?>



//筛选选中效果，签证
<?php if(isset($_GET['continent'])): ?>$(".continent-<?php echo ($_GET['continent']); ?>").addClass("curr");
<?php else: ?>
	$(".continent-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['country'])): ?>$(".country-<?php echo ($_GET['country']); ?>").addClass("curr");
<?php else: ?>
	$(".country-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['visa_type'])): ?>$(".visa_type-<?php echo ($_GET['visa_type']); ?>").addClass("curr");
<?php else: ?>
$(".visa_type-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['visa_type'])): ?>$(".visa_type-<?php echo ($_GET['visa_type']); ?>").addClass("curr");
<?php else: ?>
$(".visa_type-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['place_of_issue'])): ?>$(".place_of_issue-<?php echo ($_GET['place_of_issue']); ?>").addClass("curr");
<?php else: ?>
$(".place_of_issue-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['sent_visa_place'])): ?>$(".sent_visa_place-<?php echo ($_GET['sent_visa_place']); ?>").addClass("curr");
<?php else: ?>
$(".sent_visa_place-0").addClass("curr");<?php endif; ?>

//筛选选中效果，线路
<?php if(isset($_GET['city'])): ?>$(".city-<?php echo ($_GET['city']); ?>").addClass("curr");
<?php else: ?>
$(".city-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['days'])): ?>$(".days-<?php echo ($_GET['days']); ?>").addClass("curr");
<?php else: ?>
$(".days-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['detail_property'])): ?>$(".detail_property-<?php echo ($_GET['detail_property']); ?>").addClass("curr");
<?php else: ?>
$(".detail_property-0").addClass("curr");<?php endif; ?>

//筛选选中效果，邮轮
<?php if(isset($_GET['ship_route'])): ?>$(".ship_route-<?php echo ($_GET['ship_route']); ?>").addClass("curr");
<?php else: ?>
$(".ship_route-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['ship_company'])): ?>$(".ship_company-<?php echo ($_GET['ship_company']); ?>").addClass("curr");
<?php else: ?>
$(".ship_company-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['ship_name'])): ?>$(".ship_name-<?php echo ($_GET['ship_name']); ?>").addClass("curr");
<?php else: ?>
$(".ship_name-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['ship_depart_city'])): ?>$(".ship_depart_city-<?php echo ($_GET['ship_depart_city']); ?>").addClass("curr");
<?php else: ?>
$(".ship_depart_city-0").addClass("curr");<?php endif; ?>

<?php if(isset($_GET['ship_depart_time'])): ?>$(".ship_depart_time-<?php echo ($_GET['ship_depart_time']); ?>").addClass("curr");
<?php else: ?>
$(".ship_depart_time-0").addClass("curr");<?php endif; ?>

</script>     
<!--copyright start-->
<div class="copyright">
		<div class="copyright_content">
			<ul>
				<li><a href="#">关于</a>
					<ul>
       				<li><a href="#">关于我们</a></li>
       				<li><a href="#">联系我们</a></li>
       				<li><a href="#">加入我们</a></li>
        			<li><a href="#">版权声明</a></li>
       				</ul>
				</li>
				<li><a href="#">网站条款</a>
					<ul>
         			<li><a href="#">法律声明</a></li>
        			<li><a href="#">隐私政策</a></li>
       				<li><a href="#">服务条款</a></li>
        			<li><a href="#">用户须知</a></li>
      				</ul>
				</li>
				<li><a href="#">留言</a>
					<ul>
         			<li><a href="#">意见反馈</a></li>
        			<li><a href="#">问题流言</a></li>
       				<li><a href="#">媒体联络</a></li>
        			<li><a href="#">在线客服</a></li>
      				</ul>
				</li>
				<li><a href="#">友情链接</a>
					<ul>
         			<li><a href="#">台湾旅游局</a></li>
        			<li><a href="#">澳大利亚旅游局</a></li>
       				<li><a href="#">日本旅游局</a></li>
        			<li><a href="#">韩国旅游局</a></li>
      				</ul>
				</li>
			</ul>
		</div> <!--endof copyright_content-->
		<div class="copyright_end">
			<!--<div class="copyright_content copyright_small">
                <ul>
                    <li><a href="<?php echo U('Index/introduce/tid/1');?>">关于我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/2');?>">联系我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/3');?>">合作伙伴</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/4');?>">服务条款</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/5');?>">加入我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/6');?>">法律声明</a></li>
                </ul>
      </div>-->

</div> <!--endof copyright-->
<!--footer end here-->
</div>
<!--wrap end here-->


<script>
	//控制顶部导航栏被选中的效果
	<?php if(isset($temp_cid)): ?>$("#<?php echo ($temp_cid); ?>").addClass("active");
	<?php else: ?>
		$("#0").addClass("active");<?php endif; ?>
	
	//搜索功能
	function searchproduct(){
		var keyword = $("#search").val();
		//alert(keyword);
		self.location = "<?php echo U('Index/find');?>?keyword=" + keyword;
	}
</script>
</body>
</html>