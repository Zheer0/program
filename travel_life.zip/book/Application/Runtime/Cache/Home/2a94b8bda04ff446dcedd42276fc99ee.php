<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
<title>旅游人生</title>

<!--默认使用chrome内核进行渲染  -->
<meta name="renderer" content="webkit|ie-comp|ie-stand">

<!--安装了GCF后，可以让ie调用chrome内核进行渲染  -->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="http://apps.bdimg.com/libs/html5shiv/3.7/html5shiv.min.js"></script>
  <script src="http://apps.bdimg.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- jQuery (necessary for Bootstrap's JavaScript ) -->
<script src="/book/Public/Home/js/jquery-1.11.0.min.js"></script>
<!--  Bootstrap -->
<script src="/book/Public/Home/js/bootstrap.min.js"></script>
<link href="/book/Public/Home/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">



<!-- Custom Theme files -->
<!--  <link href="/book/Public/Home/css/style.css" rel="stylesheet" type="text/css" media="all"/>-->
<link href="/book/Public/Home/css/main.css" rel="stylesheet" type="text/css" media="all"/>

<!-- buttons.css -->	
<link href="/book/Public/Home/css/buttons.css" rel="stylesheet" type="text/css" media="all"/>

<!--  fontawesome -->
<link rel="stylesheet" href="/book/Public/Common/css/font-awesome.min.css"/>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!--favicon.ico  -->
<link rel="icon" href="/book/Public/Home/img/favicon.ico" mce_href="/book/Public/Home/img/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/book/Public/Home/img/favicon.ico">
<!--百度统计  -->

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?d57f9e6d0ea1527c4470d760bd71f2b9";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>



</head>
<body>
<div class="wrap">
<!--banner start here-->

  <div class="header">
	
		<!--navbar start here-->
            <div class="navbar-warp">
            <nav class="navbar navbar-default " role="navigation">
              
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand">
                  <img src="/book/Public/Home/img/logo_small.png" alt="Brand">
                  </a>
                </div>
            
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav">
                  	<li role="presentation"  id="0";><a href="<?php echo U('Index/index');?>">首页</a></li>

                  </ul>
					<ul class="nav navbar-nav">
						<li role="presentation"><a href="http://localhost/tp5/public/index.php/">Blog</a></li>
					</ul>
                  <form method="get" class="navbar-form navbar-right" role="search">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Search" name="keyword" id="search">
                    </div>
                    <button type="button" class="btn btn-default" onclick="searchproduct()">搜索</button>
                  </form>
                  <ul class="nav navbar-nav navbar-right">
                    <?php if(isset($userinfo["id"])): ?><li><a href="<?php echo U('Order/index');?>">欢迎您&nbsp;<?php echo ($userinfo["name"]); ?></a></li>
                    <li><a href="<?php echo U('User/logout');?>">退出</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo U('User/login');?>">登录</a></li><li><a href="<?php echo U('User/register');?>">注册</a></li><?php endif; ?>                    
                  </ul>
                </div><!-- /.navbar-collapse -->
             
            </nav>
            </div>
            <!--navbar end-->
 <!--slide start -->
	<div class="slide">
        <div id="myCarousel" class="carousel slide">
        <ol class="carousel-indicators" >
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
        <li data-target="#myCarousel" data-slide-to="4"></li>
        <li data-target="#myCarousel" data-slide-to="5"></li>
        </ol>
        <div class="carousel-inner">
        <div class="item active" sytle="height:600px;">
        <img src="/book/Public/Home/img/cover/cover01.jpg" width="1920" height="600" alt=""/></div>
        <div class="item" sytle="height:600px;">
        <img src="/book/Public/Home/img/cover/cover02.jpg" width="1920" height="600" alt=""/></div>
        <div class="item" sytle="height:600px;">
        <img src="/book/Public/Home/img/cover/cover03.jpg" width="1920" height="600" alt=""/></div>
        <div class="item" sytle="height:600px;">
        <img src="/book/Public/Home/img/cover/cover04.jpg" width="1920" height="600" alt=""/></div>
        <div class="item" sytle="height:600px;">
        <img src="/book/Public/Home/img/cover/cover05.jpg" width="1920" height="600" alt=""/></div>
        <div class="item" sytle="height:600px;">
        <img src="/book/Public/Home/img/cover/cover06.jpg" width="1920" height="600" alt=""/></div>
        </div>
        <a href="#myCarousel" data-slide="prev" class="carousel-control left">
        <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        <a href="#myCarousel" data-slide="next" class="carousel-control right">
        <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
        </div>
	</div>
<!--slide end -->
</div>
<!--header end -->
<!--私人定制 start here-->
<div class="dingzhi-wrap">
    <div class="MainPage">
    	<div class="dingzhi-top">
			 	<!-- <h3>立即定制</h3> -->
		</div>
		
		<div class="dingzhi-but-wrap">
			<a href="<?php echo U('Index/customize');?>" target="_blank" class="button button-pill button-rounded  button-primary">个人定制</a>
			<a href="<?php echo U('Index/firm');?>" target="_blank" class="button button-pill button-rounded  button-primary">企业定制</a>
		</div>  
		
    </div>
</div>
<!--私人定制 end -->
<!--bar1 start here-->
<div class="HomeContent">
	<div class="MainPage">
		<div class="ContentHead">
		 <div class="pack-top">
			 	<h3>酒店精选</h3>
		  </div>
		  </div>
			<div class="ContentGroup">
			  

			  	<?php if(is_array($best)): foreach($best as $key=>$v): ?><div class="pack-content package-grid">
					<h4><a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank"><?php echo ($v["name"]); ?></a></h4>
					<div class="price">￥<?php echo ($v["price"]); ?>起</div>
				</div><?php endforeach; endif; ?>
			<div class="clearfix"> </div>
			</div>
		</div>
	
</div>
<!--bar1 end here--> 


<!-- bar2 start -->
<div class="ContentGrey">
<div class="MainPage">
<div class="ContentHead">
	<div class="pack-top">
		<h3>猜你喜欢</h3>
	</div>

</div>
<div class="ContentGroup">
	<?php if(is_array($best2)): foreach($best2 as $key=>$v): ?><div class="Content">
	    <a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank">
          <img class="lazy_img" src="/book/Public/Uploads/<?php echo ($v["thumb"]); ?>" style="display: inline;">
          <span class="SeasonMain"><?php echo ($v["name"]); ?></span>
	<!-- <span class="SeasonWord">（4晚5天）</span> -->
	    </a>
	    </div><?php endforeach; endif; ?>
    <div style="clear:both;"></div><!-- 撑开元素 -->
</div>
</div>
</div>
<!-- bar2 end -->
<!-- bar3 start -->
<div class="HomeContent">
<div class="MainPage">
<div class="ContentHead">
	<div class="pack-top">
		<h3>高端旅游</h3>
	</div>

</div>
<div class="ContentGroup">
	<?php if(is_array($best3)): foreach($best3 as $key=>$v): ?><div class="Content">
	    <a href="<?php echo U('Index/product',array('id'=>$v['id']));?>" target="_blank">
          <img class="lazy_img" src="/book/Public/Uploads/<?php echo ($v["thumb"]); ?>" style="display: inline;">
          <span class="SeasonMain"><?php echo ($v["name"]); ?></span>
	<!-- <span class="SeasonWord">（4晚5天）</span> -->
	    </a>
	    </div><?php endforeach; endif; ?>
    <div style="clear:both;"></div><!-- 撑开元素 -->
</div>
</div>
</div>
<!-- bar3 end -->
     
<!--copyright start-->
<div class="copyright">
		<div class="copyright_content">
			<ul>
				<li><a href="#">关于</a>
					<ul>
       				<li><a href="#">关于我们</a></li>
       				<li><a href="#">联系我们</a></li>
       				<li><a href="#">加入我们</a></li>
        			<li><a href="#">版权声明</a></li>
       				</ul>
				</li>
				<li><a href="#">网站条款</a>
					<ul>
         			<li><a href="#">法律声明</a></li>
        			<li><a href="#">隐私政策</a></li>
       				<li><a href="#">服务条款</a></li>
        			<li><a href="#">用户须知</a></li>
      				</ul>
				</li>
				<li><a href="#">留言</a>
					<ul>
         			<li><a href="#">意见反馈</a></li>
        			<li><a href="#">问题流言</a></li>
       				<li><a href="#">媒体联络</a></li>
        			<li><a href="#">在线客服</a></li>
      				</ul>
				</li>
				<li><a href="#">友情链接</a>
					<ul>
         			<li><a href="#">台湾旅游局</a></li>
        			<li><a href="#">澳大利亚旅游局</a></li>
       				<li><a href="#">日本旅游局</a></li>
        			<li><a href="#">韩国旅游局</a></li>
      				</ul>
				</li>
			</ul>
		</div> <!--endof copyright_content-->
		<div class="copyright_end">
			<!--<div class="copyright_content copyright_small">
                <ul>
                    <li><a href="<?php echo U('Index/introduce/tid/1');?>">关于我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/2');?>">联系我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/3');?>">合作伙伴</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/4');?>">服务条款</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/5');?>">加入我们</a></li>
                    <li><a href="<?php echo U('Index/introduce/tid/6');?>">法律声明</a></li>
                </ul>
      </div>-->

</div> <!--endof copyright-->
<!--footer end here-->
</div>
<!--wrap end here-->


<script>
	//控制顶部导航栏被选中的效果
	<?php if(isset($temp_cid)): ?>$("#<?php echo ($temp_cid); ?>").addClass("active");
	<?php else: ?>
		$("#0").addClass("active");<?php endif; ?>
	
	//搜索功能
	function searchproduct(){
		var keyword = $("#search").val();
		//alert(keyword);
		self.location = "<?php echo U('Index/find');?>?keyword=" + keyword;
	}
</script>
</body>
</html>