<?php
return array(
	//Session前缀
	'SESSION_PREFIX' => 'opentrip_travel_admin',
	//自定义配置
	'USER_CONFIG' => array(
		'pagesize' => 10,  //每页显示的记录数
	),
	
	'LAYOUT_ON'=>true,
	
);