<?php
return array(
	//表单令牌行为绑定
    'view_filter' => array('Behavior\TokenBuildBehavior'),
);