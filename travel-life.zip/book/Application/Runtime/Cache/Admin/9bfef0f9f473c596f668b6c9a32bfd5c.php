<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	
	
	

	
	<!-- bootstrap fontawesome -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Admin/css/bootstrap.css"/>
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/font-awesome.min.css"/>
	<!--JQuery  -->
	<script src="/trip/ThinkPHP--master/Public/Common/js/jquery.min.js"></script>
	<!--date picker  -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Common/css/bootstrap-datetimepicker.min.css"/>
	<script src="/trip/ThinkPHP--master/Public/Common/js/bootstrap-datetimepicker.min.js"></script>
	<script src="/trip/ThinkPHP--master/Public/Common/js/bootstrap-datetimepicker.zh-CN.js"></script>
	<!--custom css  -->
	<link rel="stylesheet" href="/trip/ThinkPHP--master/Public/Admin/css/style.css"/>
</head>
<body>
<div class="top">
	<h1 class="left">travel life <span>后台管理系统</span></h1>
	<ul class="right">
		<li>欢迎您：<?php echo ($admin_name); ?></li>
		<li>管理员级别：<?php echo ($admin_priv); ?></li>
		<li><a href="/trip/ThinkPHP--master/index.php/" target="_blank">前台首页</a></li>
		<li><a href="<?php echo U('Login/logout');?>">退出登录</a></li>
	</ul>
</div>
<div class="main">
	<div class="menu left">
		<div class="box">
			<div class="head"><i></i><div>管理菜单</div></div>
			<ul><li><a href="<?php echo U('Index/index');?>">后台首页</a></li>
				<li><a href="<?php echo U('Product/add');?>" id="Product_add">酒店添加</a></li>
				<li><a href="<?php echo U('Product/index');?>" id="Product_index">酒店列表</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('Category/add');?>" id="Category_add">分类添加</a></li>
					<li><a href="<?php echo U('Category/index');?>" id="Category_index">分类列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Recycle/index');?>" id="Recycle_index">回收站</a></li>
				<?php if(($priv) == "0"): ?><li><a href="<?php echo U('User/index');?>" id="User_index">会员列表</a></li><?php endif; ?>
				<li><a href="<?php echo U('Admin/index');?>" id="Admin_index">管理员</a></li>
				
			</ul>
		</div>
	</div>
	<div class="content">
		<div class="item"><div class="title">产品分类</div>
<div class="top-button">
	相关操作：<a href="<?php echo U('Category/add');?>" class="light">添加分类</a>
</div>

<table class="ui-table bg-white w400">
	<thead>
		<tr>
		<th width="40%">分类名称</th>
		<th>操作</th>
		</tr>
	</thead>
	<tbody>
		<?php if(is_array($category)): foreach($category as $key=>$v): ?><tr>
			<td><?php echo str_repeat('— ',$v['level']); echo ($v["name"]); ?></td>
			<td>
			<a href="<?php echo U('Category/edit',array('id'=>$v['id']));?>" class="btn btn-primary"><i class="icon-edit"></i> 修改</a>　
			<a href="#"  data-id="<?php echo ($v["id"]); ?>" class="btn btn-danger act-del"><i class="icon-trash"></i> 删除</a>
			</td>
			</tr><?php endforeach; endif; ?>
	</tbody>
</table>
<form method="post" id="form">
	<input type="hidden" name="id" id="target_id">
</form>
<script>
	//删除
	$(".act-del").click(function(){
		if(confirm('确定要删除吗？（该分类下的产品将归于未分类）')){
			$("#target_id").val($(this).attr("data-id"));
			$("#form").attr("action","<?php echo U('Category/del');?>").submit();
		}
	});
</script></div>
	</div>
</div>
<script>
	$("#<?php echo (CONTROLLER_NAME); ?>_<?php echo (ACTION_NAME); ?>").addClass("curr");
</script>
</body>
</html>